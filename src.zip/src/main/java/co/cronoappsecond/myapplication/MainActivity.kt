package co.cronoappsecond.myapplication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.DialogInterface
import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.util.Log
import androidx.appcompat.app.AlertDialog
import co.cronoappsecond.myapplication.Model.Master
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.layout_add.view.*
import kotlinx.android.synthetic.main.layout_item.view.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class MainActivity : AppCompatActivity() {

    var rest = RestAPI()
    var c = Calendar.getInstance()
    var year = c.get(Calendar.YEAR)
    var month = c.get(Calendar.MONTH)
    var day = c.get(Calendar.DAY_OF_MONTH)
    var hour = c.get(Calendar.HOUR)
    var minute = c.get(Calendar.MINUTE)

    private var countDownTimer: CountDownTimer? = null
    private var timeLeftInMilliseconds: Long = 60000 //10min
    private var timeRunning: Boolean = false




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rest.list.add("ABS")
        rest.list.add("Chest")
        rest.list.add("Shoulder")
        rest.list.add("Back")
        rest.list.add("Legs")

        doAsync {

            activityUiThread {

                Thread.sleep(2000)
                getData()
                startStop()

            }
        }

        btn_add.setOnClickListener {

            var alertDialog = AlertDialog.Builder(this@MainActivity)

            var modal = layoutInflater.inflate(R.layout.layout_add, null)

            alertDialog.setTitle("New Item Title")

            var dpd = DatePickerDialog(this@MainActivity, DatePickerDialog.OnDateSetListener { datePicker, year, month, day ->

                modal.editTXT2.setText(""+year+"-"+month+"-"+day)
            }, year, month, day)

            var ipd = TimePickerDialog(this@MainActivity, TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->

                modal.editTXT3.setText(""+hour+":"+minute)
            },hour, minute, true)

            modal.editTXT2.setOnClickListener {

                dpd.show()
            }

            modal.editTXT3.setOnClickListener {

                ipd.show()
            }

            alertDialog.setPositiveButton("Save", DialogInterface.OnClickListener { dialogInterface, i ->

                rest.setMasterAPI(modal.editTXT.text.toString())
                recreate()
            })

            alertDialog.setView(modal)

            alertDialog.show()

        }
    }

    fun getData(){

        var masterService = rest.getMasterAPI()

        var call = masterService.getMaster()


        rest.list.forEach { at ->

            var item = layoutInflater.inflate(R.layout.layout_item, null)

            item.nameTXT.setText(at)

            scContent.addView(item)
        }


        call.enqueue(object : Callback<List<Master>> {
        override fun onFailure(call: Call<List<Master>>?, t: Throwable?) {
            Log.i("error", t.toString())
        }

        override fun onResponse(call: Call<List<Master>>?, response: Response<List<Master>>?) {

            rest.list.forEach {at->

                var item = layoutInflater.inflate(R.layout.layout_item, null)

//                    item.nameTXT.setText(at)


                scContent.addView(item)

            }

        }


        })

    }

    fun updateTimer() {
        val minutes = timeLeftInMilliseconds as Long / 60000
        val seconds = timeLeftInMilliseconds as Long % 60000 / 1000

        var timeLeftText: String

        timeLeftText = "" + minutes
        timeLeftText += ":"
        if (seconds < 10) timeLeftText += "0"
        timeLeftText += seconds

        testing.setText(""+"00:00:0"+timeLeftText)

        if (timeLeftText == "0:01") {

            val player = MediaPlayer.create(
                this@MainActivity,
                Settings.System.DEFAULT_RINGTONE_URI
            )

            player.start()

            val homeIntent = Intent(this@MainActivity, MainActivity::class.java)
            startActivity(homeIntent)
//            finish()

        }

    }

    private fun startStop() {

        if (timeRunning) {
            stopTimer()
        } else {
            startTimer()
        }
    }

    private fun stopTimer() {

        countDownTimer!!.cancel()
        timeRunning = false
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(timeLeftInMilliseconds, 1000) {
            override fun onTick(l: Long) {
                timeLeftInMilliseconds = l
                updateTimer()
            }

            override fun onFinish() {

            }
        }.start()
        timeRunning = true
    }

}
