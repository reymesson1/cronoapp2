package co.cronoappsecond.myapplication.Model

import org.json.JSONObject
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Call

interface MasterServiceDelete{

    @POST("removewalletandroid")

    fun deleteMaster(@Body data : JSONObject) : Call<String>

}