package co.cronoappsecond.myapplication.Model

class Master{

    var id : String = ""
    var date : String = ""
    var name : String = ""

}