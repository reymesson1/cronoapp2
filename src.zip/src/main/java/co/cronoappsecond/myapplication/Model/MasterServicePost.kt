package co.cronoappsecond.myapplication.Model

import org.json.JSONObject
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Call

interface MasterServicePost{

    @POST("addwalletandroid")

    fun setMasterAPI(@Body data : JSONObject) : Call<String>

}