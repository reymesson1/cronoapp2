package co.cronoappsecond.myapplication

import android.util.Log
import co.cronoappsecond.myapplication.Model.*
import com.google.gson.Gson
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*

class RestAPI{

    var retrofit = Retrofit.Builder()
//        .baseUrl("http://190.94.2.105:8082/")
        .baseUrl("http://159.203.156.208:8082/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    var list = mutableListOf<String>()


    fun getMasterAPI() : MasterService{

        return retrofit.create(MasterService::class.java)
    }

    fun setMasterAPI(name:String){

        var newMaster = Master()
        newMaster.id = Date().time.toString()
        newMaster.date = Date().toString()
        newMaster.name = name

        var json = Gson().toJson(newMaster)

        var masterServicePost = retrofit.create(MasterServicePost::class.java)

        var call = masterServicePost.setMasterAPI(JSONObject(json))

        call.enqueue(object : Callback<String>{
            override fun onFailure(call: Call<String>?, t: Throwable?) {
                Log.i("error", t.toString())
            }

            override fun onResponse(call: Call<String>?, response: Response<String>?) {
                Log.i("response", response!!.body().toString())
            }


        })



    }

    fun editMasterAPI(id:String, name:String){

        var newMaster = Master()
        newMaster.id = Date().time.toString()
        newMaster.date = Date().toString()
        newMaster.name = name

        var json = Gson().toJson(newMaster)

        var masterServiceEdit = retrofit.create(MasterServiceEdit::class.java)

        var call = masterServiceEdit.editMaster(JSONObject(json))

        call.enqueue(object : Callback<String>{
            override fun onFailure(call: Call<String>?, t: Throwable?) {
                Log.i("error", t.toString())
            }

            override fun onResponse(call: Call<String>?, response: Response<String>?) {
                Log.i("response", response!!.body().toString())
            }

        })

    }

    fun deleteMasterAPI(id:String){

        var newMaster = Master()
        newMaster.id = id
        newMaster.date = Date().toString()

        var json = Gson().toJson(newMaster)

        var masterServiceDelete = retrofit.create(MasterServiceDelete::class.java)

        var call = masterServiceDelete.deleteMaster(JSONObject(json))

        call.enqueue(object : Callback<String>{
            override fun onFailure(call: Call<String>?, t: Throwable?) {
                Log.i("error", t.toString())
            }

            override fun onResponse(call: Call<String>?, response: Response<String>?) {
                Log.i("response", response!!.body().toString())
            }


        })
    }

}